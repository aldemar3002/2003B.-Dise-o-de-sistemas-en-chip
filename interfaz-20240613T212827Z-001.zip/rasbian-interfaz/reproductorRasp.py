import sys
import os
import firebase_admin
from firebase_admin import credentials, db
import pygame
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QSlider, QPushButton, QListWidget, QListWidgetItem, QGridLayout
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont, QPixmap, QIcon
from luma.core.interface.serial import i2c
from luma.oled.device import ssd1306
from PIL import Image, ImageDraw, ImageFont
import time

# Configuración de la pantalla OLED
serial = i2c(port=1, address=0x3C)
device = ssd1306(serial, width=128, height=64)

# Configuración de Firebase
cred = credentials.Certificate('/home/semental/Downloads/prueba2-94ed4-firebase-adminsdk-puueu-dbbfb5ade9.json')  # Reemplaza con la ruta a tu archivo de credenciales JSON
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://prueba2-94ed4-default-rtdb.firebaseio.com/'
})

# Referencias a la base de datos
db_ref_movimiento = db.reference('movimiento_mbot/movimiento')
db_ref_numero = db.reference('movimiento_mbot/numero')
db_ref = db.reference('embot')

class MiVentana(QWidget):
    def _init_(self):
        super()._init_()

        self.setWindowTitle('Reproductor de Música con Control de Embot')
        self.setGeometry(100, 100, 1200, 600)
        
        # Inicializa pygame mixer
        pygame.mixer.init()
        
        # Estilo retro
        self.setStyleSheet("""
            background-color: #ffffff; color: #000000;
            QPushButton {
                background-color: #ffffff; color: #ffffff; border: 2px solid #ffffff; border-radius: 10px; padding: 10px;
            }
            QPushButton:hover {
                background-color: #000000; color: #000000;
            }
            QSlider::groove:horizontal {
                background: #ffffff;
                height: 8px;
            }
            QSlider::handle:horizontal {
                background: #ffffff;
                border: 1px solid #ffffff;
                width: 18px;
                margin: -5px 0; 
                border-radius: 3px;
            }
        """)
        
        # Layout principal dividido en tres columnas
        main_layout = QHBoxLayout()

        # Columnas
        column1 = QVBoxLayout()
        column2 = QVBoxLayout()
        column3 = QVBoxLayout()
        
        # Lista de canciones
        self.song_list = QListWidget(self)
        self.song_list.setFixedWidth(300)  # Establecer un ancho fijo para la lista de canciones
        self.load_songs()
        self.song_list.setStyleSheet("background-color: #ffffff; color: #000000;")
        column1.addWidget(self.song_list)

        # Indicador de canción actual (con animación de texto)
        font = QFont()
        font.setFamily("Arial")
        font.setPointSize(14)
        font.setBold(True)

        self.current_song_frame = QLabel(self)
        self.current_song_frame.setFont(font)
        self.current_song_frame.setStyleSheet("border: 2px solid #ff0000;")
        self.current_song_frame.setFixedHeight(50)
        self.current_song_frame.setFixedWidth(300)  # Establecer un ancho fijo para el recuadro del nombre de la canción
        self.current_song_frame.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        column2.addWidget(self.current_song_frame)

        # Botones de reproducción
        playback_buttons_layout = QHBoxLayout()
        
        # Carga las imágenes para los botones
        icon_prev = QIcon(QPixmap('/media/semental/pumas/Imagenes/Atras.png'))  # Reemplaza con la ruta a tu imagen de botón anterior
        icon_play_pause = QIcon(QPixmap('/media/semental/pumas/Imagenes/Pausa.png'))  # Reemplaza con la ruta a tu imagen de botón de play/pause
        icon_next = QIcon(QPixmap('/media/semental/pumas/Imagenes/Siguiente.png'))  # Reemplaza con la ruta a tu imagen de botón siguiente
        
        self.button_prev = QPushButton(self)
        self.button_prev.setIcon(icon_prev)
        self.button_prev.clicked.connect(self.previous_song)
        playback_buttons_layout.addWidget(self.button_prev)
        
        self.button_play_pause = QPushButton(self)
        self.button_play_pause.setIcon(icon_play_pause)
        self.button_play_pause.clicked.connect(self.play_pause_song)
        playback_buttons_layout.addWidget(self.button_play_pause)
        
        self.button_next = QPushButton(self)
        self.button_next.setIcon(icon_next)
        self.button_next.clicked.connect(self.next_song)
        playback_buttons_layout.addWidget(self.button_next)
        
        column2.addLayout(playback_buttons_layout)
        
        # Botón y slider para volumen
        self.button_volume = QLabel('Volumen', self)
        self.button_volume.setAlignment(Qt.AlignCenter)
        self.button_volume.setStyleSheet("border: 2px solid #ff0000; padding: 10px;")
        self.button_volume.setFixedHeight(40)
        self.button_volume.setMouseTracking(True)
        column2.addWidget(self.button_volume)

        self.volume_slider = QSlider(Qt.Horizontal, self)
        self.volume_slider.setMinimum(0)
        self.volume_slider.setMaximum(100)
        self.volume_slider.setValue(80)
        self.volume_slider.valueChanged.connect(self.change_volume)
        self.volume_slider.setVisible(False)
        column2.addWidget(self.volume_slider)

        self.button_volume.installEventFilter(self)

        # Timer para ocultar el slider de volumen
        self.volume_timer = QTimer(self)
        self.volume_timer.setSingleShot(True)
        self.volume_timer.timeout.connect(self.hide_volume_slider)

        # Botones en disposición de control remoto
        buttons_layout = QGridLayout()

        self.button_up = QPushButton('A', self)
        self.button_up.clicked.connect(lambda: self.move_embot("A"))
        buttons_layout.addWidget(self.button_up, 0, 1)

        self.button_left = QPushButton('C', self)
        self.button_left.clicked.connect(lambda: self.move_embot("C"))
        buttons_layout.addWidget(self.button_left, 1, 0)

        self.button_right = QPushButton('D', self)
        self.button_right.clicked.connect(lambda: self.move_embot("D"))
        buttons_layout.addWidget(self.button_right, 1, 2)

        self.button_down = QPushButton('B', self)
        self.button_down.clicked.connect(lambda: self.move_embot("B"))
        buttons_layout.addWidget(self.button_down, 2, 1)

        self.button_spin = QPushButton('Detener', self)
        self.button_spin.clicked.connect(lambda: self.move_embot("O"))
        buttons_layout.addWidget(self.button_spin, 0, 0)

        self.button_square = QPushButton('Cuadrado', self)
        self.button_square.clicked.connect(lambda: self.move_embot("cuadrado"))
        buttons_layout.addWidget(self.button_square, 0, 2)

        column3.addLayout(buttons_layout)

        # Agregar columnas al layout principal
        main_layout.addLayout(column1)
        main_layout.addLayout(column2)
        main_layout.addLayout(column3)

        self.setLayout(main_layout)

        # Timer para el texto desplazable
        self.scroll_position = 0
        self.timer = QTimer()
        self.timer.timeout.connect(self.scroll_text)
        self.timer.start(200)
        
        # Inicializar pantalla OLED
        self.init_oled_display()

        # Escuchar cambios en la base de datos Firebase
        # db_ref.child('rasp').listen(self.update_rasp_status)

    # +++++++ Metodos pantalla oled +++++++++++++++++++++++++++
    # metodo para iniciar pantalla oled
    def init_oled_display(self):
        self.font = ImageFont.load_default()
        self.image = Image.new('1', (device.width, device.height))
        self.draw = ImageDraw.Draw(self.image)
        self.update_oled_display("Iniciando...", 0, 1)

    # metodo para actualizar la pantalla oled
    def update_oled_display(self, song_name, progress, total_length):
        self.draw.rectangle((0, 0, device.width, device.height), outline=0, fill=0)  # Limpiar la pantalla

        # Dividir el nombre de la canción si es mayor a 13 caracteres
        if len(song_name) > 13:
            line1 = song_name[:13]
            line2 = song_name[13:]
            self.draw.text((0, 0), f"Canción:\n {line1}", font=self.font, fill=255)
            self.draw.text((0, 25), f"{line2}", font=self.font, fill=255)
        else:
            self.draw.text((0, 0), f"Canción:\n {song_name}", font=self.font, fill=255)

        # Slider para el progreso de la cancion
        progress_percentage = int((progress / total_length) * 100) if total_length > 0 else 0
        # Ajustar la posición del slider de progreso
        slider_top = 40  # Cambia este valor para bajar o subir el slider
        slider_bottom = slider_top + 10  # La altura del slider, ajusta según sea necesario
        self.draw.rectangle((0, slider_top, progress_percentage, slider_bottom), outline=1, fill=1)  # Dibujar el slider de progreso

        device.display(self.image)

    def eventFilter(self, source, event):
        if event.type() == event.Enter and source == self.button_volume:
            self.volume_slider.setVisible(True)
            self.volume_timer.start(3000)  # Ocultar el slider después de 3 segundos
        elif event.type() == event.Leave and source == self.button_volume:
            self.volume_timer.start(3000)  # Ocultar el slider después de 3 segundos
        return super().eventFilter(source, event)

    def hide_volume_slider(self):
        self.volume_slider.setVisible(False)

    def load_songs(self):
        songs_folder = "/media/semental/pumas/Canciones"  # Reemplaza esto con la ruta de tu carpeta de canciones
        if os.path.isdir(songs_folder):
            songs = [f for f in os.listdir(songs_folder) if f.endswith('.mp3')]
            for song in songs:
                item = QListWidgetItem(song)
                self.song_list.addItem(item)

    def play_pause_song(self):
        if self.song_list.currentItem() is None:
            self.current_song_frame.setText('No hay ninguna canción seleccionada')
            return

        if pygame.mixer.music.get_busy():
            pygame.mixer.music.pause()
            self.button_play_pause.setText('>')
            self.current_song_frame.setText('Canción actual: Pausada')
        else:
            self.play_song()
            self.button_play_pause.setText('||')  # Actualiza el botón

    def play_song(self):
        current_song = self.song_list.currentItem().text() if self.song_list.currentItem() else "Ninguna"
        if current_song != "Ninguna":
            try:
                song_path = os.path.join("/media/semental/pumas/Canciones", current_song)
                pygame.mixer.music.load(song_path)
                pygame.mixer.music.play()
                pygame.mixer.music.set_volume(self.volume_slider.value() / 100.0)  # Ajustar el volumen
                self.current_song_name = current_song
                self.scroll_position = 0
                self.current_song_frame.setText(f'Canción actual: {current_song}')
                self.button_play_pause.setText('||')  # Actualiza el botón
                # Actualizar pantalla OLED con el nombre de la canción
                self.update_oled_display(current_song, 0, 1)
            except Exception as e:
                self.current_song_frame.setText(f'Error al reproducir la canción: {str(e)}')
        else:
            self.current_song_frame.setText('Canción actual: Ninguna')

    def next_song(self):
        current_row = self.song_list.currentRow()
        total_songs = self.song_list.count()
        if current_row < total_songs - 1:
            self.song_list.setCurrentRow(current_row + 1)
            self.play_song()
            time.sleep(0.5)  # Agregar una pausa de 0.5 segundos

    def previous_song(self):
        current_row = self.song_list.currentRow()
        if current_row > 0:
            self.song_list.setCurrentRow(current_row - 1)
            self.play_song()
            time.sleep(0.5)  # Agregar una pausa de 0.5 segundos

    def change_volume(self, value):
        pygame.mixer.music.set_volume(value / 100.0)

    def toggle_volume_slider(self):
        self.volume_slider.setVisible(self.button_volume.isChecked())

    def move_embot(self, direction):
        db_ref.set({"direction": direction})
        print(f'Moviendo embot {direction}')

    def scroll_text(self):
        if hasattr(self, 'current_song_name'):
            song_name = self.current_song_name
            display_width = self.current_song_frame.width() // 10  # Aproximado de caracteres que caben
            if len(song_name) > display_width:
                self.scroll_position += 1
                if self.scroll_position > len(song_name):
                    self.scroll_position = 0
                text = song_name[self.scroll_position:] + ' ' + song_name[:self.scroll_position]
                self.current_song_frame.setText(f'Canción actual: {text}')
            else:
                self.current_song_frame.setText(f'Canción actual: {song_name}')

    def update_movimiento(self, event):
        if event.data is not None:
            command = event.data
            if command == 'A':
                self.next_song()
            elif command == 'B':
                self.previous_song()
            elif command == '#':
                pygame.mixer.music.stop()
                self.button_play_pause.setText('>')
            elif command == 'D':
                if not pygame.mixer.music.get_busy():
                    self.play_song()
                else:
                    pygame.mixer.music.unpause()
                    self.button_play_pause.setText('||')

    def update_numero(self, event):
        if event.data is not None:
            numero = event.data
            if 0 <= numero < self.song_list.count():
                self.song_list.setCurrentRow(numero)
                self.play_song()

    def closeEvent(self, event):
        pygame.mixer.music.stop()
        event.accept()

if _name_ == '_main_':
    app = QApplication(sys.argv)
    window = MiVentana()
    window.show()
    sys.exit(app.exec_())